import io.jsonwebtoken.*;
import org.junit.Test;
import utils.MD5;

import java.util.HashMap;
import java.util.Map;

public class Test1 {

    @Test
    public void c(){

        // 服务器密钥
        String serviceKey = "atguigu";

        // 客户端盐
        String ip = "127.0.0.2";

        String token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoidG9tIiwiYWdlIjoxOH0.GW2mOpw8Y4Jsc7m4v-DQxM7gs67jq9lHQA8G-QPbkVE";

        Jws<Claims> claimsJws = Jwts.parser().setSigningKey(MD5.encrypt(serviceKey + ip)).parseClaimsJws(token);

        System.out.println(claimsJws);

    }


    @Test
    public void b(){

        // 服务器密钥
        String serviceKey = "atguigu";

        // 客户端盐
        String ip = "127.0.0.1";

        String token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoidG9tIiwiYWdlIjoxOH0.GW2mOpw8Y4Jsc7m4v-DQxM7gs67jq9lHQA8G-QPbkVE";

        Jws<Claims> claimsJws = Jwts.parser().setSigningKey(MD5.encrypt(serviceKey + ip)).parseClaimsJws(token);

        System.out.println(claimsJws);

    }

    @Test
    public void a(){

        // 服务器密钥
        String serviceKey = "atguigu";

        // 客户端盐
        String ip = "127.0.0.1";

        // 用户信息
        Map<String,Object> user = new HashMap<>();
        user.put("id","123456");
        user.put("name","tom");
        user.put("age",18);

        String token = Jwts.builder()
                .setHeaderParam("typ", "JWT")
                .setHeaderParam("alg", "HS256")

                .claim("name", user.get("name"))
                .claim("age", user.get("age"))

                .signWith(SignatureAlgorithm.HS256, MD5.encrypt(serviceKey+ip))
                .compact();

        System.out.println(token);

    }


    @Test
    public void md5(){
        String ip1 = "127.0.0.1";
        String ip2 = "127.0.0.2";

        String encrypt1 = MD5.encrypt(ip1);
        String encrypt2 = MD5.encrypt(ip2);

        System.out.println(encrypt1);
        System.out.println(encrypt2);


    }
}
