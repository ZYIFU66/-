package com.atguigu.srb.gateway.filters;

import com.alibaba.nacos.api.config.filter.IFilterConfig;
import com.atguigu.srb.common.utils.JwtUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.List;

//鉴权过滤器
@Component
public class AuthorizeFilter implements GlobalFilter {
    private static final String AUTHORIZE_TOKEN = "token";
    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {

        //获取请求
        ServerHttpRequest request = exchange.getRequest();

        //获取响应
        ServerHttpResponse response = exchange.getResponse();

//        //如果是登录或注册就放行
//        if (request.getURI().getPath().contains("/login")){
//            return chain.filter(exchange);
//        }
        //获得token
        List<String> tokens = request.getHeaders().get("token");
        if (null!=tokens&&tokens.size()>0){
            String token = tokens.get(0);
            System.out.println(token);
            if (!StringUtils.isEmpty(token)){
                boolean b = JwtUtils.checkToken(token);
                if (b){
                    Long userId = JwtUtils.getUserId(token);
                    //将鉴权结果交给后端接口
                    request.mutate().header("userId",userId+"");
                    exchange.mutate().request(request);
                }
            }
        }
        System.out.println("进入网关统一鉴权过滤器");

        return chain.filter(exchange);
//        //获取请求
//        ServerHttpRequest request = exchange.getRequest();
//        //获取响应
//        ServerHttpResponse response = exchange.getResponse();
//        //如果是登录就放行
//        if (request.getURI().getPath().contains("/login")){
//            return chain.filter(exchange);
//        }
//        //获取请求头
//        HttpHeaders headers = request.getHeaders();
//        //请求头中获取令牌
//        String token = headers.getFirst(AUTHORIZE_TOKEN);
//        //判断请求头中是否有令牌
//        if (StringUtils.isEmpty(token)){
//            //响应中放入返回的状态码，没有权限访问
//            response.setStatusCode(HttpStatus.UNAUTHORIZED);
//            //返回
//            if (!JwtUtils.checkToken(token)){
//                return response.setComplete();
//            }
//            return response.setComplete();
//        }
//        //如果请求头中有令牌则解析令牌
//
//
//
//
//
//        return chain.filter(exchange);
    }

}
