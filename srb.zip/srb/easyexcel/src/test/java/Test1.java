import com.alibaba.excel.EasyExcel;
import listener.StudentDtoListener;
import org.junit.Test;
import pojo.dto.StudentExcelDTO;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Test1 {

    @Test
    public void b(){



        EasyExcel.read("d:/a.xlsx",StudentExcelDTO.class,new StudentDtoListener()).sheet("学生表格").doRead();

    }

    @Test
    public void a(){
        List<StudentExcelDTO> studentExcelDTOS = new ArrayList<>();
        for (int i = 0; i < 1001; i++) {
            StudentExcelDTO studentExcelDTO = new StudentExcelDTO();
            studentExcelDTO.setName("同学小"+i);
            studentExcelDTO.setSalary(i*1000D);
            studentExcelDTO.setBirthday(new Date());
            studentExcelDTOS.add(studentExcelDTO);
        }
        // easyexcle写出
        EasyExcel.write("d:/a.xlsx",StudentExcelDTO.class).sheet("学生表格").doWrite(studentExcelDTOS);
        System.out.println("easyexcel单元测试");
    }
}
