package listener;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import pojo.dto.StudentExcelDTO;

import java.util.ArrayList;
import java.util.List;

public class StudentDtoListener extends AnalysisEventListener<StudentExcelDTO> {

    List<StudentExcelDTO> studentExcelDTOS = new ArrayList<>();

    @Override
    public void invoke(StudentExcelDTO studentExcelDTO, AnalysisContext analysisContext) {
        studentExcelDTOS.add(studentExcelDTO);
        if(studentExcelDTOS.size()%100==0){
            System.out.println("每读取100行数据，处理一次:"+studentExcelDTOS.size());
            studentExcelDTOS.clear();
        }
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext analysisContext) {
        System.out.println("当所有数据解析完成后，收尾方法");
        System.out.println(studentExcelDTOS);
    }
}
