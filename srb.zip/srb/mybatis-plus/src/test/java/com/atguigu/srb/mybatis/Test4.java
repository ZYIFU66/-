package com.atguigu.srb.mybatis;


import com.atguigu.srb.mybatis.mapper.UserMapper;
import com.atguigu.srb.mybatis.pojo.entity.User;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
public class Test4 {

    @Autowired
    UserMapper userMapper;

    @Test
    public void b(){
        IPage<User> userIPage = new Page<>();
        userIPage.setSize(2);
        userIPage.setCurrent(2);
        IPage<User> page = userMapper.selectListByUserNamePage("n",userIPage);
        List<User> records = page.getRecords();
        long total = page.getTotal();
        long current = page.getCurrent();
        System.out.println(page);
        System.out.println(records);
        System.out.println(total);
        System.out.println(current);
    }

    @Test
    public void a(){
        IPage<User> userIPage = new Page<>();
        userIPage.setSize(2);
        userIPage.setCurrent(2);
        IPage<User> page = userMapper.selectPage(userIPage, null);
        List<User> records = page.getRecords();
        long total = page.getTotal();
        long current = page.getCurrent();
        System.out.println(page);
        System.out.println(records);
        System.out.println(total);
        System.out.println(current);
    }
}
