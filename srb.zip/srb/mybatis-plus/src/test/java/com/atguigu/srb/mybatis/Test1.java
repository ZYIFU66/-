package com.atguigu.srb.mybatis;

import com.atguigu.srb.mybatis.mapper.UserMapper;
import com.atguigu.srb.mybatis.pojo.entity.User;
import com.atguigu.srb.mybatis.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
public class Test1 {

    @Autowired
    UserMapper userMapper;

    @Autowired
    UserService userService;

    @Test
    public void b(){
        User user = new User();
        user.setId(6L);
        user.setName("hellen1");
        user.setAge(18);
        userMapper.insert(user);
    }

    @Test
    public void a(){
        List<User> users = userMapper.selectList(null);
        System.out.println(users);
    }

    @Test
    public void c(){
        List<User> users = userMapper.selectListByUserName("n");
        System.out.println(users);
    }

    @Test
    public void d(){
        List<User> list = userService.list();
        System.out.println(list);
    }

    @Test
    public void e(){
        List<User> list = userService.getListByName("j");
        System.out.println(list);
    }
}
