package com.atguigu.srb.mybatis;

import com.atguigu.srb.mybatis.mapper.UserMapper;
import com.atguigu.srb.mybatis.pojo.entity.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
public class Test3 {

    @Autowired
    UserMapper userMapper;

    @Test
    public void e(){
        User user = userMapper.selectById(12L);
        System.out.println(user);
    }

    @Test
    public void d(){
        int i = userMapper.deleteById(12L);
    }

    @Test
    public void c(){
        User user = new User();
        user.setId(13L);
        user.setName("hellen5");
        user.setAge(16);
        userMapper.updateById(user);
    }

    @Test
    public void b(){
        User user = new User();
        user.setName("hellen5");
        user.setAge(22);
        userMapper.insert(user);
    }

    @Test
    public void a(){
        List<User> users = userMapper.selectList(null);
        System.out.println();
    }
}
