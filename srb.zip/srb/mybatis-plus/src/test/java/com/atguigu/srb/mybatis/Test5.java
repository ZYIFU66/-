package com.atguigu.srb.mybatis;

import com.atguigu.srb.mybatis.mapper.ProductMapper;
import com.atguigu.srb.mybatis.pojo.entity.Product;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class Test5 {

    @Autowired
    ProductMapper productMapper;

    @Test
    public void a(){

        // 小李查询价格
        Product productLi = productMapper.selectById(1L);

        // 小王查询价格
        Product productWang = productMapper.selectById(1L);

        // 小李修改价格
        productLi.setPrice(productLi.getPrice()+50);
        productMapper.updateById(productLi);

        // 小王修改价格
        productWang.setPrice(productWang.getPrice()-30);
        productMapper.updateById(productWang);

        // 数据库中的最终价格
        Product product = productMapper.selectById(1L);
        System.out.println("数据库中最终价格："+product.getPrice());

    }
}
