package com.atguigu.srb.mybatis;

import com.atguigu.srb.mybatis.mapper.ProductMapper;
import com.atguigu.srb.mybatis.mapper.UserMapper;
import com.atguigu.srb.mybatis.pojo.entity.Product;
import com.atguigu.srb.mybatis.pojo.entity.User;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import org.junit.jupiter.api.Test;
import org.junit.platform.commons.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.function.Consumer;

@SpringBootTest
public class Test6 {

    @Autowired
    UserMapper userMapper;

    @Test
    public void test8() {



        //8 查询名字中包含n，年龄大于10且小于20的用户，查询条件来源于用户输入，是可选的
        String name = null;
        Integer ageBegin = 10;
        Integer ageEnd = null;

        QueryWrapper<User> userQueryWrapper = new QueryWrapper<>();

        userQueryWrapper
                .like(StringUtils.isNotBlank(name), "name", name)
                .ge(null!=ageBegin,"age",ageBegin)
                .lt(null!=ageEnd,"age",ageEnd);

        List<User> users = userMapper.selectList(userQueryWrapper);
        System.out.println(users);

    }

    @Test
    public void t7() {
        // 7 查询名字中包含n，且（年龄小于18或email为空的用户），并将这些用户的年龄设置为18，邮箱设置为 user@atguigu.com
        UpdateWrapper<User> userUpdateWrapper = new UpdateWrapper<>();
        userUpdateWrapper
                .set("age", 17)
                .set("email", "atguigu@user.com")
                .like("name", "n")
                .and(i -> i.lt("age", 18).or().isNull("email"));
        userMapper.update(null, userUpdateWrapper);
    }

    @Test
    public void t6() {
        // 6 查询id不大于3的所有用户的id列表
        String num = "3 or true";// 从前端传递的参数
        QueryWrapper<User> userQueryWrapper = new QueryWrapper<>();
        userQueryWrapper.inSql("id", "select id from user where id <= " + num);
        List<User> users = userMapper.selectList(userQueryWrapper);
        System.out.println(users);
    }

    @Test
    public void t5() {
        // 5 查询所有用户的用户名和年龄
        QueryWrapper<User> userQueryWrapper = new QueryWrapper<>();
        userQueryWrapper.select("name", "age");
        List<User> users = userMapper.selectList(userQueryWrapper);
        System.out.println(users);
    }

    @Test
    public void t4B() {
        // 4 并将这些用户的年龄设置为18，邮箱设置为 user@atguigu.com
        //4 查询名字中包含n，且（年龄小于18或email为空的用户）
        QueryWrapper<User> userQueryWrapper = new QueryWrapper<>();
        userQueryWrapper
                .like("name", "n")
                .and((q) -> q.lt("age", 18).or().isNull("email"));
        User user = new User();
        user.setAge(18);
        user.setEmail("user@atguigu.com");
        int update = userMapper.update(user, userQueryWrapper);
        System.out.println(update);
    }

    @Test
    public void t4A() {
        //4 查询名字中包含n，且（年龄小于18或email为空的用户）
        QueryWrapper<User> userQueryWrapper = new QueryWrapper<>();
        userQueryWrapper
                .like("name", "n")
                .and((q) -> q.lt("age", 18).or().isNull("email"));
        List<User> users = userMapper.selectList(userQueryWrapper);
        System.out.println(users);
    }

    @Test
    public void t4() {
        Consumer<QueryWrapper<User>> queryWrapperConsumer = new Consumer<QueryWrapper<User>>() {
            @Override
            public void accept(QueryWrapper<User> userQueryWrapper) {
                userQueryWrapper
                        .lt("age", 18)
                        .or()
                        .isNull("email");
            }
        };
        //4 查询名字中包含n，且（年龄小于18或email为空的用户）
        QueryWrapper<User> userQueryWrapper = new QueryWrapper<>();
        userQueryWrapper
                .like("name", "n")
                .and(queryWrapperConsumer);
        List<User> users = userMapper.selectList(userQueryWrapper);
        System.out.println(users);

    }

    @Test
    public void t3() {
        // 3 删除email为空的用户
        QueryWrapper<User> userQueryWrapper = new QueryWrapper<>();
        userQueryWrapper.isNull("email");
        int delete = userMapper.delete(userQueryWrapper);
        System.out.println(delete);
    }

    @Test
    public void t2() {
        // 2 按年龄降序查询用户，如果年龄相同则按id升序排列
        QueryWrapper<User> userQueryWrapper = new QueryWrapper<>();
        userQueryWrapper.orderByDesc("age").orderByDesc("id");
        List<User> users = userMapper.selectList(userQueryWrapper);
        System.out.println(users);
    }

    @Test
    public void t1() {
        //1 查询名字中包含n，年龄大于等于10且小于等于20，email不为空的用户
        QueryWrapper<User> userQueryWrapper = new QueryWrapper<>();
        userQueryWrapper
                .like("name", "n")
                .between("age", 10, 20)
                .isNotNull("email");
        List<User> users = userMapper.selectList(userQueryWrapper);
        System.out.println(users);
    }
}
