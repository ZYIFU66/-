package com.atguigu.srb.mybatis.pojo.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("user")
public class User {

    //@TableId(type=IdType.ASSIGN_ID)// mp的雪花id
    @TableId(type=IdType.AUTO)// mysql自增id
    private  Long id;// 默认使用mp的雪花id

    @TableField
    private  String  name;

    @TableField
    private  Integer age;

    @TableField
    private  String  email;

    @TableField(value = "create_time",fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime  updateTime;


    @TableField(value = "is_deleted")
    @TableLogic
    private Integer deleted;

}
