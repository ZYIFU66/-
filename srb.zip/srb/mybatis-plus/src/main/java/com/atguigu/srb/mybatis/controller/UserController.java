package com.atguigu.srb.mybatis.controller;


import com.atguigu.srb.mybatis.pojo.entity.User;
import com.atguigu.srb.mybatis.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("user")
@CrossOrigin
public class UserController {

    @Autowired
    UserService userService;

    @GetMapping("/list")
    public List<User> list(HttpServletRequest request){
        Cookie[] cookies = request.getCookies();
        if(null!=cookies&&cookies.length>0){
            // 获得cookie中的用户登录令牌或者凭据信息，判断用户是否登录
        }
        String token = request.getHeader("token");
        List<User> list = userService.list();
        return list; 
    }
}
