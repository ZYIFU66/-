package com.atguigu.srb.mybatis.mapper;

import com.atguigu.srb.mybatis.pojo.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface UserMapper extends BaseMapper<User> {

    List<User> selectListByUserName(@Param("name") String name);

    IPage<User>  selectListByUserNamePage(@Param("name") String name,IPage<User> userIPage);
}
