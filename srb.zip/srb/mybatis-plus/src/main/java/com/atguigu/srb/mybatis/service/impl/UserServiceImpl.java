package com.atguigu.srb.mybatis.service.impl;

import com.atguigu.srb.mybatis.mapper.UserMapper;
import com.atguigu.srb.mybatis.pojo.entity.User;
import com.atguigu.srb.mybatis.service.UserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService  {
    
    @Override
    public List<User> getListByName(String name) {
        List<User> users = baseMapper.selectListByUserName(name);
        return users;
    }
}
