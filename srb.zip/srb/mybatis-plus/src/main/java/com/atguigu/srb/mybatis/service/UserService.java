package com.atguigu.srb.mybatis.service;

import com.atguigu.srb.mybatis.pojo.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

public interface UserService extends IService<User> {
    List<User> getListByName(String name);
}
