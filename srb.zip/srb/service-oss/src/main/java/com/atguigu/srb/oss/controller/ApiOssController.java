package com.atguigu.srb.oss.controller;


import com.atguigu.srb.common.result.R;
import com.atguigu.srb.oss.service.OssService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/oss/file")
//@CrossOrigin
public class ApiOssController {

    @Autowired
    OssService ossService;

    @PostMapping("/uploadImage")
    public R uploadImage(@RequestParam("file") MultipartFile multipartFile,String module){
        // 调用阿里云的oss服务接口，保存上传的图片
        String url = ossService.uploadImage(multipartFile,module);

        // 将上传的图片的元数据url返回给页面
        return R.ok().data("url",url);
    }
}
