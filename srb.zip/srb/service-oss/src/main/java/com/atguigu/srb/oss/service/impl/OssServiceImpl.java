package com.atguigu.srb.oss.service.impl;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.atguigu.srb.oss.service.OssService;
import com.atguigu.srb.oss.utils.OssProperties;
import org.joda.time.DateTime;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

@Service
public class OssServiceImpl implements OssService {
    @Override
    public String uploadImage(MultipartFile multipartFile, String module) {
        String url = "https://";
        InputStream inputStream = null;
        try {
            inputStream = multipartFile.getInputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        String originalFilename = multipartFile.getOriginalFilename();
        String fileName = module + new DateTime().toString("/yyyy/MM/dd/") + UUID.randomUUID().toString().replace("-","") +"."+StringUtils.getFilenameExtension(originalFilename);
        OSS oss = new OSSClientBuilder().build(OssProperties.ENDPOINT,OssProperties.KEY_ID,OssProperties.KEY_SECRET);
        oss.putObject(OssProperties.BUCKET_NAME,fileName,inputStream,null);

        url = url + OssProperties.BUCKET_NAME + "." + OssProperties.ENDPOINT + "/" + fileName;
        return url;
    }

    public static void main(String[] args) {
        String originalFilename = "sdifjasofe.efoewfjaio12313.feofjeaw1.12312-123123.123.jpg";
        String substring = originalFilename.substring(originalFilename.lastIndexOf(".") + 1);
        System.out.println(substring);
        String filenameExtension = StringUtils.getFilenameExtension(originalFilename);
        System.out.println(filenameExtension);

        String folder = new DateTime().toString("/yyyy/MM/dd/");
        System.out.println(folder);
    }
}
