package com.atguigu.srb.oss;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClient;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.Bucket;
import com.aliyun.oss.model.CannedAccessControlList;
import com.atguigu.srb.oss.utils.OssProperties;
import org.junit.Test;

import java.io.File;
import java.util.List;

public class Test1 {

    @Test
    public void d(){

        OSS oss = new OSSClientBuilder().build("oss-cn-shenzhen.aliyuncs.com","LTAI5t6ZdD2N2HDDn7yyvieS","S6x5IBbbrKG3bhWlWfF0xeftM7hCqD");
        oss.putObject("srb-0730","a/test1.jpg",new File("d:/a.jpg"),null);
        oss.shutdown();

    }

    @Test
    public void c(){

        OSS oss = new OSSClientBuilder().build("oss-cn-shenzhen.aliyuncs.com","LTAI5t6ZdD2N2HDDn7yyvieS","S6x5IBbbrKG3bhWlWfF0xeftM7hCqD");
        List<Bucket> buckets = oss.listBuckets();
        for (Bucket bucket : buckets) {
            System.out.println(bucket.getName());
        }
        oss.shutdown();

    }

    @Test
    public void b(){

        OSS oss = new OSSClientBuilder().build("oss-cn-shenzhen.aliyuncs.com","LTAI5t6ZdD2N2HDDn7yyvieS","S6x5IBbbrKG3bhWlWfF0xeftM7hCqD");
        oss.setBucketAcl("srb-0730-test", CannedAccessControlList.PublicRead);
        oss.shutdown();

    }

    @Test
    public void a(){

        OSS oss = new OSSClientBuilder().build("oss-cn-shenzhen.aliyuncs.com","LTAI5t6ZdD2N2HDDn7yyvieS","S6x5IBbbrKG3bhWlWfF0xeftM7hCqD");
        oss.createBucket("srb-0730-test");
        oss.shutdown();

    }
}
