package com.atguigu.srb.sms;


import com.aliyuncs.CommonRequest;
import com.aliyuncs.CommonResponse;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import com.google.gson.Gson;
import org.junit.Test;

import java.util.HashMap;

public class Test1 {

    @Test
    public void a() throws ClientException {
        // 配置sdk的客户端
        DefaultProfile defaultProfile = DefaultProfile.getProfile("cn-shenzhen","LTAI5t6ZdD2N2HDDn7yyvieS","S6x5IBbbrKG3bhWlWfF0xeftM7hCqD");
        IAcsClient iAcsClient = new DefaultAcsClient(defaultProfile);

        // 配置请求参数
        CommonRequest commonRequest = new CommonRequest();
        /***
         * 通用参数
         */
        commonRequest.setSysAction("SendSms");// 产品接口
        commonRequest.setSysVersion("2017-05-25");// 版本
        commonRequest.setSysDomain("dysmsapi.aliyuncs.com");// 网关
        commonRequest.setSysMethod(MethodType.POST);
        /***
         * 接口参数
         */
        commonRequest.putQueryParameter("RegionId", "cn-shenzhen");
        commonRequest.putQueryParameter("PhoneNumbers","13307410498");
        commonRequest.putQueryParameter("SignName","北京课时教育");
        commonRequest.putQueryParameter("TemplateCode","SMS_217425770");
        HashMap<String, Object> map = new HashMap<>();
        map.put("code", "8888");
        Gson gson = new Gson();
        String param = gson.toJson(map);
        System.out.println(param);
        commonRequest.putQueryParameter("TemplateParam",param);

        // 发送请求
        CommonResponse commonResponse = iAcsClient.getCommonResponse(commonRequest);
        int httpStatus = commonResponse.getHttpStatus();
        boolean success = commonResponse.getHttpResponse().isSuccess();
        System.out.println(httpStatus);
        System.out.println(success);

    }
}
