package com.atguigu.srb.sms.utils;


import lombok.Data;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "aliyun.sms")
public class SmsProperties implements InitializingBean {

    private String regionId;
    private String keyId;
    private String keySecret;
    private String templateCode;
    private String signName;

    public static String REGION_Id;
    public static String KEY_ID;
    public static String KEY_SECRET;
    public static String TEMPLATE_CODE;
    public static String SIGN_NAME;

    @Override
    public void afterPropertiesSet() throws Exception {
        System.out.println(regionId);
        System.out.println(keyId);
        System.out.println(keySecret);
        System.out.println(templateCode);
        System.out.println(signName);
        REGION_Id = this.regionId;
        KEY_ID = this.keyId;
        KEY_SECRET = this.keySecret;
        TEMPLATE_CODE = this.templateCode;
        SIGN_NAME = this.signName;
    }
}
