package com.atguigu.srb.sms.service.impl;

import com.alibaba.fastjson.JSON;
import com.aliyuncs.CommonRequest;
import com.aliyuncs.CommonResponse;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import com.atguigu.srb.common.utils.RandomUtils;
import com.atguigu.srb.sms.service.SmsService;
import com.atguigu.srb.sms.utils.SmsProperties;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.HashMap;

@Service
public class SmsServiceImpl implements SmsService {

    @Autowired
    RedisTemplate redisTemplate;

    @Override
    public void sendCode(String mobile) {
        // 发送短信
        // 配置sdk的客户端
        DefaultProfile defaultProfile = DefaultProfile.getProfile(SmsProperties.REGION_Id,SmsProperties.KEY_ID,SmsProperties.KEY_SECRET);
        IAcsClient iAcsClient = new DefaultAcsClient(defaultProfile);

        // 配置请求参数
        CommonRequest commonRequest = new CommonRequest();
        /***
         * 通用参数
         */
        commonRequest.setSysAction("SendSms");// 产品接口
        commonRequest.setSysVersion("2017-05-25");// 版本
        commonRequest.setSysDomain("dysmsapi.aliyuncs.com");// 网关
        commonRequest.setSysMethod(MethodType.POST);
        /***
         * 接口参数
         */
        commonRequest.putQueryParameter("RegionId", SmsProperties.REGION_Id);
        commonRequest.putQueryParameter("PhoneNumbers",mobile);
        commonRequest.putQueryParameter("SignName",SmsProperties.SIGN_NAME);
        commonRequest.putQueryParameter("TemplateCode",SmsProperties.TEMPLATE_CODE);
        HashMap<String, Object> map = new HashMap<>();
        String sixBitRandom = RandomUtils.getSixBitRandom();// 验证码
        map.put("code", sixBitRandom);
        Gson gson = new Gson();
        String param = gson.toJson(map);
        System.out.println(param);
        commonRequest.putQueryParameter("TemplateParam",param);

        // 发送请求
        CommonResponse commonResponse = null;
        try {
            commonResponse = iAcsClient.getCommonResponse(commonRequest);
        } catch (ClientException e) {
            e.printStackTrace();
        }
        int httpStatus = commonResponse.getHttpStatus();
        boolean success = commonResponse.getHttpResponse().isSuccess();
        HashMap<String, String> stringStringHashMap = new HashMap<>();
        HashMap hashMap = JSON.parseObject(commonResponse.getData(), stringStringHashMap.getClass());
        String OK = (String)hashMap.get("Code");
        System.out.println(httpStatus);
        System.out.println(success);
        // 短信发送成功后，将验证码存入redis
        if(success==true&&httpStatus==200&&OK.equals("OK")){
            redisTemplate.opsForValue().set("srb:sms:code:" + mobile,sixBitRandom);
        }
    }
}
