package com.atguigu.srb.sms.service;

public interface SmsService {
    void sendCode(String mobile);
}
