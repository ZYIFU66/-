package com.atguigu.srb.sms.controller;


import com.atguigu.srb.common.result.R;
import com.atguigu.srb.sms.client.CoreUserInfoClient;
import com.atguigu.srb.sms.service.SmsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/sms/")
//@CrossOrigin
public class ApiSmsController {

    @Autowired
    SmsService smsService;

    @Autowired
    CoreUserInfoClient coreUserInfoClient;

    @GetMapping("testSentinel")
    public R testSentinel(){
        System.out.println("sentinel测试");
        return R.ok();
    }

    @GetMapping("sendCode/{mobile}")
    public R sendCode(@PathVariable String mobile){
        // 查询手机号是否已经存在
        boolean b = coreUserInfoClient.isMobileExist(mobile);
        if(!b){
            // smsService.sendCode(mobile);
            return R.ok();
        }else {
            return R.error().message("手机号已经注册");
        }
    }
}
