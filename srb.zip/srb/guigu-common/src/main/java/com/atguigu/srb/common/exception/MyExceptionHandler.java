package com.atguigu.srb.common.exception;


import com.atguigu.srb.common.result.R;
import org.springframework.jdbc.BadSqlGrammarException;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.sql.SQLSyntaxErrorException;

//@Component
//@RestControllerAdvice
public class MyExceptionHandler {

    /***
     * 通用异常处理
     * @param e
     * @return
     */
    @ExceptionHandler(Exception.class)
    public R exceptionHandler(Exception e){
        System.out.println("通用异常捕获");
        return R.error().message(e.getMessage());
    }

    @ExceptionHandler(SQLSyntaxErrorException.class)
    public R sqlSyntaxErrorException(SQLSyntaxErrorException e){
        System.out.println("sql语句结构异常捕获");
        return R.error().message(e.getMessage());
    }

    @ExceptionHandler(BadSqlGrammarException.class)
    public R badSqlGrammarException(BadSqlGrammarException e){
        System.out.println("sql语法异常捕获");
        return R.error().message(e.getMessage());
    }

    @ExceptionHandler(BusinessException.class)
    public R businessException(BusinessException e){
        System.out.println("自定义业务异常捕获");
        return R.error().message(e.getMessage());
    }
}
