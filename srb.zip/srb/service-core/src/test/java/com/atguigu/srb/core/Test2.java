package com.atguigu.srb.core;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;

@SpringBootTest
public class Test2 {

    @Autowired
    RedisTemplate redisTemplate;

    @Test
    public void d(){
        redisTemplate.boundHashOps("map1").put("hk1","hv1");
        redisTemplate.boundHashOps("map1").put("hk2","hv2");
        redisTemplate.boundHashOps("map1").put("hk3","hv3");

    }

    @Test
    public void c(){
        Object k1 = redisTemplate.opsForValue().get("k1");
        System.out.println(k1);
    }

    @Test
    public void b(){
        redisTemplate.opsForValue().set("k1","v1");
        System.out.println(1);
    }

}
