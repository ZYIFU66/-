package com.atguigu.srb.core;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.generator.AutoGenerator;
import com.baomidou.mybatisplus.generator.config.DataSourceConfig;
import com.baomidou.mybatisplus.generator.config.GlobalConfig;
import com.baomidou.mybatisplus.generator.config.PackageConfig;
import com.baomidou.mybatisplus.generator.config.StrategyConfig;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;
import org.checkerframework.checker.units.qual.A;
import org.junit.Test;

public class Test1 {

    @Test
    public void b(){
        String sysPath = System.getProperty("user.dir");
        System.out.println(sysPath);
    }

    @Test
    public void a(){
        System.out.println(1);

        // 创建代码生成器
        AutoGenerator autoGenerator = new AutoGenerator();

        // 配置全局参数
        GlobalConfig globalConfig = new GlobalConfig();
        globalConfig.setAuthor("Mr.xu");
        globalConfig.setSwagger2(true);
        globalConfig.setIdType(IdType.AUTO);
        globalConfig.setServiceName("%sService");
        String sysPath = System.getProperty("user.dir");
        globalConfig.setOutputDir(sysPath+"/src/main/java");
        autoGenerator.setGlobalConfig(globalConfig);

        // 配置数据库参数
        DataSourceConfig dataSourceConfig = new DataSourceConfig();
        dataSourceConfig.setDbType(DbType.MYSQL);
        dataSourceConfig.setDriverName("com.mysql.cj.jdbc.Driver");
        dataSourceConfig.setUrl("jdbc:mysql://localhost:3306/srb_core?characterEncoding=utf-8&useSSL=true");
        dataSourceConfig.setUsername("root");
        dataSourceConfig.setPassword("123456");
        autoGenerator.setDataSource(dataSourceConfig);

        // 配置代码的生成包参数
        PackageConfig packageConfig = new PackageConfig();
        packageConfig.setParent("com.atguigu.srb.core");
        packageConfig.setEntity("pojo.entity");
        autoGenerator.setPackageInfo(packageConfig);

        // 配置其他参数
        StrategyConfig strategy = new StrategyConfig();
        strategy.setNaming(NamingStrategy.underline_to_camel);//数据库表映射到实体的命名策略
        strategy.setColumnNaming(NamingStrategy.underline_to_camel);//数据库表字段映射到实体的命名策略
        strategy.setEntityLombokModel(true); // lombok
        strategy.setLogicDeleteFieldName("is_deleted");//逻辑删除字段名
        strategy.setEntityBooleanColumnRemoveIsPrefix(true);//去掉布尔值的is_前缀（确保tinyint(1)）
        strategy.setRestControllerStyle(true); //restful api风格控制器
        autoGenerator.setStrategy(strategy);

        // 执行
        autoGenerator.execute();
    }
}
