package com.atguigu.srb.core.controller.api;


import com.atguigu.srb.common.result.R;
import com.atguigu.srb.core.pojo.entity.UserInfo;
import com.atguigu.srb.core.pojo.vo.LoginVO;
import com.atguigu.srb.core.pojo.vo.RegisterVO;
import com.atguigu.srb.core.pojo.vo.UserInfoVO;
import com.atguigu.srb.core.service.UserInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;


@RestController
@RequestMapping("/api/core/userInfo")
//@CrossOrigin
public class ApiUserInfoController {

    @Autowired
    UserInfoService userInfoService;

    @PostMapping("register")
    public R register(@RequestBody RegisterVO registerVO){
        userInfoService.register(registerVO);
        return R.ok();
    }

    @PostMapping("login")
    public R login(@RequestBody LoginVO loginVO, HttpServletRequest request){
        String ip = request.getRemoteAddr();// 获得请求发出端的ip
        UserInfoVO userInfoVO = userInfoService.login(loginVO,ip);
        return R.ok().data("userInfo",userInfoVO);
    }

    @GetMapping("/isMobileExist/{mobile}")
    public boolean isMobileExist(@PathVariable String mobile){
        boolean b = userInfoService.isMobileExist(mobile);
        return b;
    }

}

