package com.atguigu.srb.core.controller.admin;


import com.atguigu.srb.common.exception.BusinessException;
import com.atguigu.srb.common.result.R;
import com.atguigu.srb.common.result.ResponseEnum;
import com.atguigu.srb.core.pojo.entity.IntegralGrade;
import com.atguigu.srb.core.service.IntegralGradeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;


@RestController
@RequestMapping("/admin/core/integralGrade")
//@CrossOrigin
@Api(tags = "后台后端管理系统接口")
public class AdminIntegralGradeController {

    @Autowired
    IntegralGradeService integralGradeService;

    @GetMapping("list")
    public R getList(){
        List<IntegralGrade> list = integralGradeService.list();
        return R.ok().data("list",list);
    }


    @ApiOperation(value = "根据主键id查询积分对象接口方法")
    @GetMapping("getById/{id}")
    public R getById(@ApiParam(value = "主键id") @PathVariable Long id){
        IntegralGrade integralGrade = integralGradeService.getById(id);
        return R.ok().data("integralGrade",integralGrade);
    }


    @PostMapping("save")
    public R saveIntegralGrade(@RequestBody IntegralGrade integralGrade){
        BigDecimal borrowAmount = integralGrade.getBorrowAmount();
        Integer integralEnd = integralGrade.getIntegralEnd();
        Integer integralStart = integralGrade.getIntegralStart();
        if(borrowAmount.intValue()<=0||integralEnd<=0||integralStart<=0){
            // 不允许积分等级出现0或者负数
            throw new BusinessException(ResponseEnum.BORROW_AMOUNT_NULL_ERROR);
        }
        boolean b = integralGradeService.save(integralGrade);
        return R.ok().data("result",b);
    }

    @DeleteMapping("removeById/{id}")
    public R deleteById(@PathVariable Long id){
        boolean b = integralGradeService.removeById(id);
        return R.ok().data("result",b);
    }

    @PutMapping("updateById")
    public R updateById(@RequestBody IntegralGrade integralGrade){
        boolean b = integralGradeService.updateById(integralGrade);
        return R.ok().data("result",b);
    }


    public static void main(String[] args) {

    }




}

