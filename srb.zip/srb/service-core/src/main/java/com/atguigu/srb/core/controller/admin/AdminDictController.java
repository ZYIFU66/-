package com.atguigu.srb.core.controller.admin;


import com.alibaba.excel.EasyExcel;
import com.atguigu.srb.common.result.R;
import com.atguigu.srb.core.pojo.dto.DictExcelDTO;
import com.atguigu.srb.core.pojo.entity.Dict;
import com.atguigu.srb.core.service.DictService;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;


@RestController
@RequestMapping("/admin/core/dict")
//@CrossOrigin
public class AdminDictController {

    @Autowired
    DictService dictService;

    @GetMapping("listByParentId/{parentId}")
    public R getDictListByParentId(@PathVariable Long parentId){
        List<Dict> list =  dictService.getDictListByParentId(parentId);
        return R.ok().data("list",list);
    }


    @PostMapping("import")
    public R importDict(@RequestParam("file")MultipartFile multipartFile){
        // 使用easyexcel的api上传文件数据
        dictService.importImage(multipartFile);
        return R.ok();
    }

    @GetMapping("exportDict")
    public void exportDict(HttpServletResponse response){
        ServletOutputStream outputStream = null;
        response.setContentType("application/vnd.ms-excel");
        response.setCharacterEncoding("utf-8");
        // 这里URLEncoder.encode可以防止中文乱码 当然和easyexcel没有关系
        String fileName = null;
        try {
            fileName = URLEncoder.encode("mydict", "UTF-8").replaceAll("\\+", "%20");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");

        try {
             outputStream = response.getOutputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // 查询字典表集合
        List<DictExcelDTO> dictExcelDTOS = dictService.getDictExcelDTOList();
        EasyExcel.write(outputStream, DictExcelDTO.class).sheet("字典表数据").doWrite(dictExcelDTOS);
    }

}

