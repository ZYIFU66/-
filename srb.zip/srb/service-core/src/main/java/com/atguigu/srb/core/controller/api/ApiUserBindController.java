package com.atguigu.srb.core.controller.api;


import com.alibaba.fastjson.JSON;
import com.atguigu.srb.base.util.JwtUtils;
import com.atguigu.srb.common.result.R;
import com.atguigu.srb.core.hfb.RequestHelper;
import com.atguigu.srb.core.pojo.vo.UserBindVO;
import com.atguigu.srb.core.service.UserBindService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@RestController
@RequestMapping("/api/core/userBind")
public class ApiUserBindController {

    @Autowired
    private UserBindService userBindService;

    @PostMapping("/auth/bind")
    public R IdBind(@RequestBody UserBindVO userBindVO, HttpServletRequest request){
        //获取token
        String token = request.getHeader("token");
        //获取id
        Long userId = JwtUtils.getUserId(token);
        //绑定
        String form = userBindService.IdBind(userBindVO,userId);

        return R.ok().data("form",form);

    }

    @ApiOperation("账号绑定异步回调")
    @PostMapping("/notify")
    public String notify(HttpServletRequest request){
        Map<String ,Object> paraMap = RequestHelper.switchMap(request.getParameterMap());
        System.out.println("用户账号绑定异步回调："+ JSON.toJSONString(paraMap));

        //校验签名
        if (!RequestHelper.isSignEquals(paraMap)){
            System.out.println("签名错误");
            return "fail";
        }

        //修改绑定状态
        userBindService.notify(paraMap);

        return "success";
    }
}
