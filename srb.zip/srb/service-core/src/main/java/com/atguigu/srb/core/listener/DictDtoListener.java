package com.atguigu.srb.core.listener;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.excel.read.listener.ReadListener;
import com.atguigu.srb.core.mapper.DictMapper;
import com.atguigu.srb.core.pojo.dto.DictExcelDTO;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

public class DictDtoListener extends AnalysisEventListener<DictExcelDTO> {

    DictMapper dictMapper;

    List<DictExcelDTO> dictExcelDTOS = new ArrayList<>();

    public DictDtoListener(DictMapper baseMapper) {
        this.dictMapper = baseMapper;
    }

    @Override
    public void invoke(DictExcelDTO dictExcelDTO, AnalysisContext analysisContext) {
        dictExcelDTOS.add(dictExcelDTO);
        if(dictExcelDTOS.size()%10==0){
            System.out.println("每读取10行数据，处理一次,保存数据库:"+dictExcelDTOS.size());
            dictMapper.insertBatch(dictExcelDTOS);
            dictExcelDTOS.clear();
        }
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext analysisContext) {
        System.out.println("当所有数据解析完成后，收尾方法,保存数据库");
        dictMapper.insertBatch(dictExcelDTOS);
        System.out.println(dictExcelDTOS);
    }
}
