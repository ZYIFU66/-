package com.atguigu.srb.core.controller.api;


import com.atguigu.srb.base.util.JwtUtils;
import com.atguigu.srb.common.result.R;
import com.atguigu.srb.core.pojo.entity.BorrowInfo;
import com.atguigu.srb.core.service.BorrowInfoService;
import com.atguigu.srb.core.service.BorrowerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;

@RestController
@RequestMapping("/api/core/borrowInfo")
public class ApiBorrowInfoController {

    @Autowired
    private BorrowInfoService borrowInfoService;

    @GetMapping("/auth/getBorrowAmount")
    public R getBorrowAmount(HttpServletRequest request){
        String token = request.getHeader("token");
        Long userId = JwtUtils.getUserId(token);

        BigDecimal borrowAmount = borrowInfoService.getBorrowAmount(userId);


        return R.ok().data("borrowAmount",borrowAmount);
    }

    @GetMapping("getBorrowInfoStatus")
    public R getBorrowInfoStatus(HttpServletRequest request){
        String token = request.getHeader("token");
        Long userId = JwtUtils.getUserId(token);
        Integer borrowInfoStatus =  borrowInfoService.getBorrowInfoStatus(userId);
        return R.ok().data("borrowInfoStatus",borrowInfoStatus);
    }


    //保存借款申请信息
    @PostMapping("save")
    public R applysave(@RequestBody BorrowInfo borrowInfo,HttpServletRequest request){
        System.out.println(borrowInfo);
        //BorrowInfo(id=null, userId=null, amount=9988, period=9, borrowYearRate=12, returnMethod=4,
        // moneyUse=5, status=null, createTime=null, updateTime=null, deleted=null)
        String token = request.getHeader("token");
        Long userId = JwtUtils.getUserId(token);


        borrowInfoService.applysave(borrowInfo,userId);

        return R.ok().message("提交成功");
    }

}
