package com.atguigu.srb.core.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 积分等级表 前端控制器
 * </p>
 *
 * @author Mr.xu
 * @since 2022-12-02
 */
@RestController
@RequestMapping("/integralGrade")
public class IntegralGradeController {

}

