package com.atguigu.srb.core.service;

import com.atguigu.srb.core.pojo.entity.Product;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Mr.xu
 * @since 2022-12-02
 */
public interface ProductService extends IService<Product> {

}
