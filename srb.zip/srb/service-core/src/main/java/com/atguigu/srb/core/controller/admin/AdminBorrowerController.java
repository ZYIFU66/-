package com.atguigu.srb.core.controller.admin;


import com.atguigu.srb.common.result.R;
import com.atguigu.srb.core.pojo.entity.Borrower;
import com.atguigu.srb.core.pojo.vo.BorrowerApprovalVO;
import com.atguigu.srb.core.pojo.vo.BorrowerDetailVO;
import com.atguigu.srb.core.service.BorrowerService;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/admin/core/borrower")
public class AdminBorrowerController {

    @Autowired
    private BorrowerService borrowerService;


    @ApiOperation("借款额度审批")
    @PostMapping("/approval")
    public R apprpval(@RequestBody BorrowerApprovalVO borrowerApprovalVO){
        borrowerService.approval(borrowerApprovalVO);
        return R.ok().message("审批完成");
    }

    //获取借款人分页列表
    @GetMapping("/list/{page}/{limit}")
    public R borrowlist(
            @ApiParam(value = "当前页码", required = true)
            @PathVariable Long page,

            @ApiParam(value = "每页记录数", required = true)
            @PathVariable Long limit,

            @ApiParam(value = "查询关键字", required = false)
            @RequestParam String keyword){
        System.out.println(page);
        System.out.println(limit);
        System.out.println(keyword);
        Page<Borrower> borrowerPage = new Page<>(page,limit);
        IPage<Borrower> pageModel = borrowerService.listPage(borrowerPage,keyword);


        return R.ok().data("pageModel", pageModel);
    }

    @GetMapping("/show/{id}")
    public R showId(@PathVariable Long id){
        System.out.println("id="+id);
        BorrowerDetailVO borrowerDetailVO = borrowerService.getBorrowerbyId(id);
        return R.ok().data("borrowerDetailVO",borrowerDetailVO);
    }
}
