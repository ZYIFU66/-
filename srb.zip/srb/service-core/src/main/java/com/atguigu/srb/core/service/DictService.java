package com.atguigu.srb.core.service;

import com.atguigu.srb.core.pojo.dto.DictExcelDTO;
import com.atguigu.srb.core.pojo.entity.Dict;
import com.baomidou.mybatisplus.extension.service.IService;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface DictService extends IService<Dict> {

    void importImage(MultipartFile multipartFile);

    List<DictExcelDTO> getDictExcelDTOList();

    List<Dict> getDictListByParentId(Long parentId);

    List<Dict> findByDictCode(String dictCode);

    String getNameByParentDictCodeAndValue(String industry, Integer id);

    List<Dict> returnMethod();

    List<Dict> moneyUse();

}
