package com.atguigu.srb.core.service.impl;

import com.atguigu.srb.core.mapper.LendMapper;
import com.atguigu.srb.core.mapper.UserInfoMapper;
import com.atguigu.srb.core.pojo.entity.Lend;
import com.atguigu.srb.core.pojo.entity.LendItem;
import com.atguigu.srb.core.mapper.LendItemMapper;
import com.atguigu.srb.core.pojo.entity.UserInfo;
import com.atguigu.srb.core.pojo.vo.InvestVO;
import com.atguigu.srb.core.service.LendItemService;
import com.atguigu.srb.core.service.LendService;
import com.atguigu.srb.core.util.LendNoUtils;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 * 标的出借记录表 服务实现类
 * </p>
 *
 * @author Mr.xu
 * @since 2022-12-02
 */
@Service
public class LendItemServiceImpl extends ServiceImpl<LendItemMapper, LendItem> implements LendItemService {

    @Autowired
    private LendMapper lendMapper;

    @Autowired
    private UserInfoMapper userInfoMapper;

    @Autowired
    private LendService lendService;

    @Override
    public String commitInvest(InvestVO investVO) {

        //获取标的信息
        Long userId = investVO.getInvestUserId();
        QueryWrapper<Lend> lendQueryWrapper = new QueryWrapper<>();
        lendQueryWrapper.eq("user_id",userId);
        Lend lend = lendMapper.selectOne(lendQueryWrapper);

        UserInfo userInfo = userInfoMapper.selectById(userId);
        //标的不能超卖：（已投金额+本次投资金额）>=标的金额（超卖）
        //已投金额+本次投资金额
        String investAount = investVO.getInvestAount();
        BigDecimal add = lend.getInvestAmount().add(new BigDecimal(investAount));
        //在这要做判断如果超卖需要返回

        //账户可用余额充足

        //在商户平台生产投资信息

        //标的下的投资信息
        LendItem lendItem = new LendItem();
        lendItem.setInvestUserId(userId);//投资人id
        lendItem.setInvestName(userInfo.getName());
        String lendNo = LendNoUtils.getLendNo();
        lendItem.setLendItemNo(lendNo);
        lendItem.setInvestAmount(new BigDecimal(investAount));
        lendItem.setLendId(investVO.getLendId());
        lendItem.setInvestTime(LocalDateTime.now());
        lendItem.setLendStartDate(lend.getLendStartDate());
        lendItem.setLendEndDate(lend.getLendEndDate());
        //预期收益

        BigDecimal interestCount = lendService.getInterestCount(lendItem.getInvestAmount(), lendItem.getLendYearRate(), lend.getPeriod(), lend.getReturnMethod());

        lendItem.setExpectAmount(interestCount);

        //实际收益

        lendItem.setRealAmount(new BigDecimal("0"));

        //设置状态
        lendItem.setStatus(0);
        //添加到数据库
        baseMapper.insert(lendItem);

        //组装投资相关的参数提交到汇付宝资金托管平台
        

        //在托管平台同步用户的投资信息，修改用户的账户资金信息
        //获取投资人的绑定协议号
        //获取借款人的绑定协议号
        //封装提交至汇付宝的参数
        //在资金托管平台上的投资订单的唯一编号，要和lendItemNo保持一致
        //构建充值自助表单


        return null;
    }
}
