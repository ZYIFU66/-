package com.atguigu.srb.core.controller.admin;


import com.atguigu.srb.common.result.R;
import com.atguigu.srb.core.pojo.entity.Lend;
import com.atguigu.srb.core.service.LendService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/admin/core/lend")
//@CrossOrigin
@Api(tags = "后台后端标的管理系统接口")
public class AdminLendController {

    @Autowired
    private LendService lendService;

    //标的管理
    @GetMapping("list")
    public R lendList(){

        List<Lend> list = lendService.lendList();
        return R.ok().data("list",list);
    }

    //标的详情
    @GetMapping("/show/{id}")
    public R showIdLend(@PathVariable Long id){

        Map<String,Object> lendDetail = new HashMap<>();
        lendDetail = lendService.showIdLend(id);

        return R.ok().data("lendDetail",lendDetail);
    }
}
