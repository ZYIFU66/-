package com.atguigu.srb.core.pojo.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BorrowerDetailVO {

    //状态
    private String status;

    //创建时间
    private LocalDateTime createTime;

    //姓名
    private String name;

    //性别
    private String sex;

    //年龄
    private Integer age;

    //手机
    private String mobile;

    //学历
    private String education;

    //是否结婚
    private String marry;

    //行业
    private String industry;

    //还款来源
    private String returnSource;

    //身份证号
    private String idCard;

    //联系人姓名
    private String contactsName;

    //联系人手机
    private String contactsMobile;

    //联系人关系
    private String contactsRelation;

    @ApiModelProperty(value = "月收入")
    private String income;

    //图片URL地址
    private List<BorrowerAttachVO> borrowerAttachVOList;

}
