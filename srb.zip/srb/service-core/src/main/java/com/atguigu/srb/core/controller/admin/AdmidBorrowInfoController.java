package com.atguigu.srb.core.controller.admin;

import com.atguigu.srb.common.result.R;
import com.atguigu.srb.core.pojo.entity.BorrowInfo;
import com.atguigu.srb.core.pojo.vo.BorrowInfoApprovalVO;
import com.atguigu.srb.core.service.BorrowInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/admin/core/borrowInfo")
public class AdmidBorrowInfoController {

    @Autowired
    private BorrowInfoService borrowInfoService;

    @GetMapping("list")
    public R borrowInfolist(){
        List<BorrowInfo> list = borrowInfoService.getBorrowinfolist();
        return R.ok().data("list",list);
    }

    @GetMapping("show/{id}")
    public R showInfoDetailById(@PathVariable Long id){
        System.out.println("=======id======="+id);

        Map<String,Object> borrowInfoDetail = new HashMap<>();
        borrowInfoDetail = borrowInfoService.showInfoDetailById(id);

        return R.ok().data("borrowInfoDetail",borrowInfoDetail);
    }

    @PostMapping("approval")
    public R approval(@RequestBody BorrowInfoApprovalVO borrowInfoApprovalVO){

        borrowInfoService.approval(borrowInfoApprovalVO);

        return R.ok().message("审批完成");
    }
}
