package com.atguigu.srb.core.controller.api;


import com.atguigu.srb.base.util.JwtUtils;
import com.atguigu.srb.common.result.R;
import com.atguigu.srb.core.pojo.vo.BorrowerVO;
import com.atguigu.srb.core.service.BorrowerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api/core/borrower")
public class ApiBorrowerController {

    @Autowired
    private BorrowerService borrowerService;


    @PostMapping("save")
    public R borrowerSave(@RequestBody BorrowerVO borrowerVO, HttpServletRequest request){

        String token = request.getHeader("token");
        Long userId = JwtUtils.getUserId(token);

        borrowerService.saveByUserId(borrowerVO,userId);


        return R.ok().message("个人信息提交完成");
    }

    @GetMapping("auth/getBorrowerStatus")
    public R getBorrowerStatus(HttpServletRequest request){

        String token = request.getHeader("token");
        Long userId = JwtUtils.getUserId(token);

        Integer status = borrowerService.getStatusByUserId(userId);

        return R.ok().data("borrowerStatus",status);
    }

}
