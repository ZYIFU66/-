package com.atguigu.srb.core.service.impl;

import com.atguigu.srb.core.enums.LendStatusEnum;
import com.atguigu.srb.core.enums.ReturnMethodEnum;
import com.atguigu.srb.core.mapper.BorrowerMapper;
import com.atguigu.srb.core.pojo.entity.BorrowInfo;
import com.atguigu.srb.core.pojo.entity.Borrower;
import com.atguigu.srb.core.pojo.entity.Lend;
import com.atguigu.srb.core.mapper.LendMapper;
import com.atguigu.srb.core.pojo.vo.BorrowInfoApprovalVO;
import com.atguigu.srb.core.pojo.vo.BorrowerDetailVO;
import com.atguigu.srb.core.service.BorrowerService;
import com.atguigu.srb.core.service.DictService;
import com.atguigu.srb.core.service.LendService;
import com.atguigu.srb.core.util.*;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 标的准备表 服务实现类
 * </p>
 *
 * @author Mr.xu
 * @since 2022-12-02
 */
@Service
public class LendServiceImpl extends ServiceImpl<LendMapper, Lend> implements LendService {

    @Autowired
    private DictService dictService;

    @Autowired
    private BorrowerMapper borrowerMapper;

    @Autowired
    private BorrowerService borrowerService;

    @Override
    public void createLend(BorrowInfoApprovalVO borrowInfoApprovalVO, BorrowInfo borrowInfo) {

        Lend lend = new Lend();

        lend.setUserId(borrowInfo.getUserId());
        lend.setBorrowInfoId(borrowInfo.getId());
        //使用配置类生成标的标编号
        lend.setLendNo(LendNoUtils.getLendNo());
        lend.setTitle(borrowInfoApprovalVO.getTitle());
        lend.setAmount(borrowInfo.getAmount());
        lend.setPeriod(borrowInfo.getPeriod());
        //年化利率
        lend.setLendYearRate(borrowInfoApprovalVO.getLendYearRate());
        //平台服务费率
        lend.setServiceRate(borrowInfoApprovalVO.getServiceRate());
        lend.setReturnMethod(borrowInfo.getReturnMethod());
        lend.setLowestAmount(new BigDecimal(100));
        lend.setInvestAmount(new BigDecimal(0));
        lend.setInvestNum(0);
        lend.setPublishDate(LocalDateTime.now());

        //开始日期
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate parse = LocalDate.parse(borrowInfoApprovalVO.getLendStartDate(), dateTimeFormatter);
        lend.setLendStartDate(parse);

        //结束日期
        LocalDate localEndDate = parse.plusMonths(borrowInfo.getPeriod());
        lend.setLendEndDate(localEndDate);

        lend.setLendInfo(borrowInfoApprovalVO.getLendInfo());

        //平台预计收益
        //月收益
        BigDecimal divide = lend.getServiceRate().divide(new BigDecimal(12), 8, BigDecimal.ROUND_DOWN);
        //年收益
        BigDecimal multiply = lend.getAmount().multiply(divide).multiply(new BigDecimal(lend.getPeriod()));

        lend.setExpectAmount(multiply);

        //实际收益
        lend.setRealAmount(new BigDecimal(0));

        //状态
        lend.setStatus(LendStatusEnum.INVEST_RUN.getStatus());

        lend.setCheckTime(LocalDateTime.now());
        lend.setCheckAdminId(1L);

        baseMapper.insert(lend);


    }

    @Override
    public List<Lend> lendList() {

        List<Lend> list = baseMapper.selectList(null);
        list.forEach(lend -> {
            String returnMethodname = dictService.getNameByParentDictCodeAndValue("returnMethod",lend.getReturnMethod());
            String statusName = LendStatusEnum.getMsgByStatus(lend.getStatus());

            lend.getParam().put("returnMethod",returnMethodname);
            lend.getParam().put("status",statusName);


        });

        return list;
    }

    @Override
    public Map<String, Object> showIdLend(Long id) {


        QueryWrapper<Lend> lendQueryWrapper = new QueryWrapper<>();
        lendQueryWrapper.eq("id",id);

        Lend lend = baseMapper.selectOne(lendQueryWrapper);

        String returnMethodname = dictService.getNameByParentDictCodeAndValue("returnMethod",lend.getReturnMethod());
        String statusName = LendStatusEnum.getMsgByStatus(lend.getStatus());
        lend.getParam().put("returnMethod",returnMethodname);
        lend.getParam().put("status",statusName);

        Map<String,Object> objectMap = new HashMap<>();

        objectMap.put("lend",lend);
        Long userId = lend.getUserId();

        QueryWrapper<Borrower> borrowerQueryWrapper = new QueryWrapper<>();
        borrowerQueryWrapper.eq("user_id",userId);
        Borrower borrower = borrowerMapper.selectOne(borrowerQueryWrapper);

        BorrowerDetailVO borrowerDetailVO = borrowerService.getBorrowerbyId(borrower.getId());

        objectMap.put("borrower",borrowerDetailVO);


        return objectMap;
    }

    @Override
    public BigDecimal getInterestCount(BigDecimal investAmount, BigDecimal lendYearRate, Integer period, Integer returnMethod) {

        BigDecimal bigDecimal = new BigDecimal("0");

        if (returnMethod.intValue() == ReturnMethodEnum.ONE.getMethod()){
            bigDecimal = Amount1Helper.getInterestCount(investAmount,lendYearRate,period);
        }
        if (returnMethod.intValue() == ReturnMethodEnum.TWO.getMethod()){
            bigDecimal = Amount2Helper.getInterestCount(investAmount,lendYearRate,period);
        }
        if (returnMethod.intValue() == ReturnMethodEnum.THREE.getMethod()){
            bigDecimal = Amount3Helper.getInterestCount(investAmount,lendYearRate,period);
        }
        if (returnMethod.intValue() == ReturnMethodEnum.FOUR.getMethod()){
            bigDecimal = Amount4Helper.getInterestCount(investAmount,lendYearRate,period);
        }


        return bigDecimal;
    }


}
