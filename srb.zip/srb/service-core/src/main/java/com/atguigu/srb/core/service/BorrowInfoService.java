package com.atguigu.srb.core.service;

import com.atguigu.srb.core.pojo.entity.BorrowInfo;
import com.atguigu.srb.core.pojo.vo.BorrowInfoApprovalVO;
import com.baomidou.mybatisplus.extension.service.IService;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 借款信息表 服务类
 * </p>
 *
 * @author Mr.xu
 * @since 2022-12-02
 */
public interface BorrowInfoService extends IService<BorrowInfo> {

    BigDecimal getBorrowAmount(Long userId);

    Integer getBorrowInfoStatus(Long userId);

    void applysave(BorrowInfo borrowInfo, Long userId);

    List<BorrowInfo> getBorrowinfolist();

    Map<String, Object> showInfoDetailById(Long id);

    void approval(BorrowInfoApprovalVO borrowInfoApprovalVO);

}
