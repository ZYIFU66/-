package com.atguigu.srb.core.pojo.vo;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InvestVO {

    private Long lendId;

    //投标金额
    private String investAount;

    //用户ID
    private Long investUserId;

    //用户姓名
    private String investName;
}
