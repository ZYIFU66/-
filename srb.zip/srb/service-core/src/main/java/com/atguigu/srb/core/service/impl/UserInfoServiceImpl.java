package com.atguigu.srb.core.service.impl;

import com.atguigu.srb.common.utils.JwtUtils;
import com.atguigu.srb.common.exception.Assert;
import com.atguigu.srb.common.result.ResponseEnum;
import com.atguigu.srb.common.utils.MD5;
import com.atguigu.srb.common.utils.RegexValidateUtils;
import com.atguigu.srb.core.mapper.UserAccountMapper;
import com.atguigu.srb.core.mapper.UserLoginRecordMapper;
import com.atguigu.srb.core.pojo.entity.UserAccount;
import com.atguigu.srb.core.pojo.entity.UserInfo;
import com.atguigu.srb.core.mapper.UserInfoMapper;
import com.atguigu.srb.core.pojo.entity.UserLoginRecord;
import com.atguigu.srb.core.pojo.vo.LoginVO;
import com.atguigu.srb.core.pojo.vo.RegisterVO;
import com.atguigu.srb.core.pojo.vo.UserInfoVO;
import com.atguigu.srb.core.service.UserInfoService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 用户基本信息 服务实现类
 * </p>
 *
 * @author Mr.xu
 * @since 2022-12-02
 */
@Service
public class UserInfoServiceImpl extends ServiceImpl<UserInfoMapper, UserInfo> implements UserInfoService {

    @Autowired
    RedisTemplate redisTemplate;

    @Autowired
    UserAccountMapper userAccountMapper;

    @Autowired
    UserLoginRecordMapper userLoginRecordMapper;

    @Override
    public void register(RegisterVO registerVO) {
        String mobile = registerVO.getMobile();
        Integer userType = registerVO.getUserType();
        String password = registerVO.getPassword();
        String code = registerVO.getCode();

        // 异常断言（优雅）
        Assert.notNull(mobile, ResponseEnum.MOBILE_NULL_ERROR);
        boolean b = RegexValidateUtils.checkCellphone(mobile);
        Assert.isTrue(b,ResponseEnum.MOBILE_ERROR);
        Assert.notNull(code,ResponseEnum.CODE_NULL_ERROR);
        String codeCache = (String)redisTemplate.opsForValue().get("srb:sms:code:" + mobile);
        Assert.equals(code,codeCache,ResponseEnum.CODE_ERROR);

        // 注册成功，生成用户信息
        UserInfo userInfo = new UserInfo();
        userInfo.setName(mobile);
        userInfo.setPassword(MD5.encrypt(password));
        userInfo.setMobile(mobile);
        userInfo.setUserType(userType);
        userInfo.setNickName(mobile);
        baseMapper.insert(userInfo);

        UserAccount userAccount = new UserAccount();
        userAccount.setUserId(userInfo.getId());
        userAccountMapper.insert(userAccount);

    }

    @Override
    public UserInfoVO login(LoginVO loginVO, String ip) {
        String mobile = loginVO.getMobile();
        Integer userType = loginVO.getUserType();
        String password = loginVO.getPassword();

        // 验证用户是否存在
        QueryWrapper<UserInfo> userInfoQueryWrapper = new QueryWrapper<>();
        userInfoQueryWrapper.eq("mobile",mobile);
        userInfoQueryWrapper.eq("user_type",userType);
        UserInfo userInfo = baseMapper.selectOne(userInfoQueryWrapper);

        Assert.notNull(userInfo,ResponseEnum.LOGIN_MOBILE_ERROR);
        Assert.equals(userInfo.getPassword(),MD5.encrypt(password),ResponseEnum.LOGIN_PASSWORD_ERROR);

        // 用户登录成功,记录登录日志
        UserLoginRecord userLoginRecord = new UserLoginRecord();
        userLoginRecord.setUserId(userInfo.getId());
        userLoginRecord.setIp(ip);
        userLoginRecordMapper.insert(userLoginRecord);
        // 生成用户令牌token，jwt算法
        String token = JwtUtils.createToken(userInfo.getId(), userInfo.getName());

        UserInfoVO userInfoVO = new UserInfoVO();
        userInfoVO.setToken(token);
        userInfoVO.setName(userInfo.getName());
        userInfoVO.setNickName(userInfo.getNickName());
        userInfoVO.setHeadImg(userInfo.getHeadImg());
        userInfoVO.setMobile(userInfo.getMobile());
        userInfoVO.setUserType(userType);

        return userInfoVO;
    }

    @Override
    public boolean isMobileExist(String mobile) {
        QueryWrapper<UserInfo> userInfoQueryWrapper = new QueryWrapper<>();
        userInfoQueryWrapper.eq("mobile",mobile);
        Integer integer = baseMapper.selectCount(userInfoQueryWrapper);
        if(integer>0){
            return true;
        }
        return false;
    }

}
