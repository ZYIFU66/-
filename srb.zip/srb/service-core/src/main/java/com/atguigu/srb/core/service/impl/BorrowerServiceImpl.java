package com.atguigu.srb.core.service.impl;

import com.atguigu.srb.core.enums.BorrowerStatusEnum;
import com.atguigu.srb.core.enums.IntegralEnum;
import com.atguigu.srb.core.mapper.*;
import com.atguigu.srb.core.pojo.entity.Borrower;
import com.atguigu.srb.core.pojo.entity.BorrowerAttach;
import com.atguigu.srb.core.pojo.entity.UserInfo;
import com.atguigu.srb.core.pojo.entity.UserIntegral;
import com.atguigu.srb.core.pojo.vo.BorrowerApprovalVO;
import com.atguigu.srb.core.pojo.vo.BorrowerAttachVO;
import com.atguigu.srb.core.pojo.vo.BorrowerDetailVO;
import com.atguigu.srb.core.pojo.vo.BorrowerVO;
import com.atguigu.srb.core.service.BorrowerAttachService;
import com.atguigu.srb.core.service.BorrowerService;
import com.atguigu.srb.core.service.DictService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 借款人 服务实现类
 * </p>
 *
 * @author Mr.xu
 * @since 2022-12-02
 */
@Service
public class BorrowerServiceImpl extends ServiceImpl<BorrowerMapper, Borrower> implements BorrowerService {

    @Autowired
    private BorrowerAttachMapper borrowerAttachMapper;

    @Autowired
    private UserInfoMapper userInfoMapper;

    @Autowired
    private DictService dictService;

    @Autowired
    private BorrowerAttachService borrowerAttachService;

    @Override
    public void saveByUserId(BorrowerVO borrowerVO, Long userId) {

        UserInfo userInfo = userInfoMapper.selectById(userId);


        //保存借款人信息
        Borrower borrower = new Borrower();
        BeanUtils.copyProperties(borrowerVO, borrower);
        borrower.setUserId(userId);
        borrower.setName(userInfo.getName());
        borrower.setIdCard(userInfo.getIdCard());
        borrower.setMobile(userInfo.getMobile());
        borrower.setStatus(BorrowerStatusEnum.AUTH_RUN.getStatus());//认证中
        borrower.setIsMarry(borrowerVO.getMarry()?1:0);
        baseMapper.insert(borrower);

        //保存附件
        List<BorrowerAttach> borrowerAttachList = borrowerVO.getBorrowerAttachList();
        borrowerAttachList.forEach(borrowerAttach -> {
            borrowerAttach.setBorrowerId(borrower.getId());
            borrowerAttachMapper.insert(borrowerAttach);
        });

        //更新会员状态，更新为认证中
        userInfo.setBorrowAuthStatus(BorrowerStatusEnum.AUTH_RUN.getStatus());
        userInfoMapper.updateById(userInfo);


//        //提交用户信息
//        //获取用户信息
//
//        Integer sex = borrowerVO.getSex();//获取性别
//        Integer age = borrowerVO.getAge();//获取年龄
//        Integer education = borrowerVO.getEducation();//获取学历
//        Boolean marry = borrowerVO.getMarry();//获取结婚信息
//        Integer industry = borrowerVO.getIndustry();//获取行业信息
//        Integer income = borrowerVO.getIncome();//获取月收入信息
//        Integer returnSource = borrowerVO.getReturnSource();//获取还款来源
//        String contactsName = borrowerVO.getContactsName();//获取联系人名称
//        String contactsMobile = borrowerVO.getContactsMobile();//获取联系人手机
//        Integer contactsRelation = borrowerVO.getContactsRelation();//获取联系人关系
//        List<BorrowerAttach> borrowerAttachList = borrowerVO.getBorrowerAttachList();//获取借款人附件资料
//
//        //判断用户信息有无值
//        QueryWrapper<Borrower> queryWrapper = new QueryWrapper<>();
//        queryWrapper.eq("user_id",userId);
//
//        Borrower borrower = baseMapper.selectOne(queryWrapper);
//
//        if (borrower == null){
//            borrower = new Borrower();
//            borrower.setSex(sex);
//            borrower.setAge(age);
//            borrower.setEducation(education);
//            borrower.setIsMarry((marry?1:0));
//            borrower.setIndustry(industry);
//            borrower.setIncome(income);
//            borrower.setReturnSource(returnSource);
//            borrower.setContactsName(contactsName);
//            borrower.setContactsMobile(contactsMobile);
//            borrower.setContactsRelation(contactsRelation);
//
//            baseMapper.insert(borrower);
//            //将用户证件的图片url保存到数据库
//
//        }else {
//            borrower.setSex(sex);
//            borrower.setAge(age);
//            borrower.setEducation(education);
//            borrower.setIsMarry((marry?1:0));
//            borrower.setIndustry(industry);
//            borrower.setIncome(income);
//            borrower.setReturnSource(returnSource);
//            borrower.setContactsName(contactsName);
//            borrower.setContactsMobile(contactsMobile);
//            borrower.setContactsRelation(contactsRelation);
//
//            baseMapper.updateById(borrower);
//        }





    }

    @Override
    public Integer getStatusByUserId(Long userId) {

        QueryWrapper<Borrower> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("status").eq("user_id",userId);
        Borrower borrower = baseMapper.selectOne(queryWrapper);

        Integer status = borrower.getStatus();


        return status;
    }

    @Override
    public IPage<Borrower> listPage(Page<Borrower> borrowerPage, String keyword) {
        QueryWrapper<Borrower> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isEmpty(keyword)){
            return baseMapper.selectPage(borrowerPage,null);
        }

        queryWrapper.like("name",keyword)
                .or().like("id_card",keyword)
                .or().like("mobile",keyword)
                .orderByDesc("id");

        return baseMapper.selectPage(borrowerPage,queryWrapper);
    }

    @Override
    public BorrowerDetailVO getBorrowerbyId(Long id) {
        QueryWrapper<Borrower> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("id",id);
        //创建借款人详情类
        BorrowerDetailVO borrowerDetailVO = new BorrowerDetailVO();
        //查询借款人信息
        Borrower borrower = baseMapper.selectOne(queryWrapper);
        //进行信息的copy
        BeanUtils.copyProperties(borrower,borrowerDetailVO);

        //进行借款人借款申请信息的判断
        String msgByStatus = BorrowerStatusEnum.getMsgByStatus(borrower.getStatus());
        borrowerDetailVO.setStatus(msgByStatus);

        borrowerDetailVO.setSex(borrower.getSex()==1?"男":"女");
        borrowerDetailVO.setMarry(borrower.getIsMarry()==1?"已婚":"未婚");

        //下拉列表数据
        //行业，还款来源，联系人关系，学历
        borrowerDetailVO.setIndustry(dictService.getNameByParentDictCodeAndValue("industry",borrower.getIndustry()));
        System.out.println("======="+borrowerDetailVO.getIndustry());
        borrowerDetailVO.setReturnSource(dictService.getNameByParentDictCodeAndValue("returnSource",borrower.getReturnSource()));
        borrowerDetailVO.setContactsRelation(dictService.getNameByParentDictCodeAndValue("relation",borrower.getContactsRelation()));
        borrowerDetailVO.setEducation(dictService.getNameByParentDictCodeAndValue("education",borrower.getEducation()));
        borrowerDetailVO.setIncome(dictService.getNameByParentDictCodeAndValue("income",borrower.getIncome()));

        //获取附件列表
        List<BorrowerAttachVO> borrowerAttachVOS = borrowerAttachService.selectBorrowerAttachVOList(id);
        borrowerDetailVO.setBorrowerAttachVOList(borrowerAttachVOS);

        return borrowerDetailVO;
    }

    @Autowired
    private UserIntegralMapper userIntegralMapper;

    @Override
    public void approval(BorrowerApprovalVO borrowerApprovalVO) {
        //借款人认证状态
        Long borrowerId = borrowerApprovalVO.getBorrowerId();
        Borrower borrower = baseMapper.selectById(borrowerId);
        borrower.setStatus(borrowerApprovalVO.getStatus());
        baseMapper.updateById(borrower);

        Long userId = borrower.getUserId();
        UserInfo userInfo = userInfoMapper.selectById(userId);

        //添加积分
        UserIntegral userIntegral = new UserIntegral();
        userIntegral.setUserId(userId);
        userIntegral.setIntegral(borrowerApprovalVO.getInfoIntegral());
        userIntegral.setContent("借款人基本信息");
        userIntegralMapper.insert(userIntegral);

        int curIntegral = userInfo.getIntegral()+borrowerApprovalVO.getInfoIntegral();
        if (borrowerApprovalVO.getIsIdCardOk()){
            curIntegral += IntegralEnum.BORROWER_IDCARD.getIntegral();
            userIntegral = new UserIntegral();
            userIntegral.setUserId(userId);
            userIntegral.setIntegral(IntegralEnum.BORROWER_IDCARD.getIntegral());
            userIntegral.setContent(IntegralEnum.BORROWER_IDCARD.getMsg());
            userIntegralMapper.insert(userIntegral);
        }

        if(borrowerApprovalVO.getIsHouseOk()) {
            curIntegral += IntegralEnum.BORROWER_HOUSE.getIntegral();
            userIntegral = new UserIntegral();
            userIntegral.setUserId(userId);
            userIntegral.setIntegral(IntegralEnum.BORROWER_HOUSE.getIntegral());
            userIntegral.setContent(IntegralEnum.BORROWER_HOUSE.getMsg());
            userIntegralMapper.insert(userIntegral);
        }

        if(borrowerApprovalVO.getIsCarOk()) {
            curIntegral += IntegralEnum.BORROWER_CAR.getIntegral();
            userIntegral = new UserIntegral();
            userIntegral.setUserId(userId);
            userIntegral.setIntegral(IntegralEnum.BORROWER_CAR.getIntegral());
            userIntegral.setContent(IntegralEnum.BORROWER_CAR.getMsg());
            userIntegralMapper.insert(userIntegral);
        }

        userInfo.setIntegral(curIntegral);
        //修改审核状态
        userInfo.setBorrowAuthStatus(borrowerApprovalVO.getStatus());
        userInfoMapper.updateById(userInfo);


        //修改审核状态
    }
}
