package com.atguigu.srb.core.controller.api;


import com.atguigu.srb.common.result.R;
import com.atguigu.srb.core.pojo.entity.Lend;
import com.atguigu.srb.core.service.LendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/core/lend")
public class ApiLendController {

    @Autowired
    private LendService lendService;

    @GetMapping("list")
    public R listLend(){
        List<Lend> lendList = lendService.lendList();

        return R.ok().data("lendList",lendList);
    }

    @GetMapping("show/{id}")
    public R showIdLend(@PathVariable Long id){

        Map<String,Object> lendDetail = new HashMap<>();

        lendDetail = lendService.showIdLend(id);

        return R.ok().data("lendDetail",lendDetail);
    }
}
