package com.atguigu.srb.core.service.impl;

import com.alibaba.excel.EasyExcel;
import com.atguigu.srb.core.listener.DictDtoListener;
import com.atguigu.srb.core.pojo.dto.DictExcelDTO;
import com.atguigu.srb.core.pojo.entity.Dict;
import com.atguigu.srb.core.mapper.DictMapper;
import com.atguigu.srb.core.service.DictService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Service
public class DictServiceImpl extends ServiceImpl<DictMapper, Dict> implements DictService {

    @Autowired
    RedisTemplate redisTemplate;

    @Override
    public void importImage(MultipartFile multipartFile) {
        InputStream inputStream = null;
        try {
            inputStream = multipartFile.getInputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        EasyExcel.read(inputStream, DictExcelDTO.class,new DictDtoListener(baseMapper)).sheet("数据字典").doRead();
    }

    @Override
    public List<DictExcelDTO> getDictExcelDTOList() {
        List<DictExcelDTO> dictExcelDTOS = new ArrayList<>();
        List<Dict> dicts = baseMapper.selectList(null);
        dictExcelDTOS = dicts.stream().map(dict->{
            DictExcelDTO dictExcelDTO = new DictExcelDTO();
            BeanUtils.copyProperties(dict,dictExcelDTO);
            return dictExcelDTO;
        }).collect(Collectors.toList());
        return dictExcelDTOS;
    }

    @Override
    public List<Dict> getDictListByParentId(Long parentId) {
        List<Dict> dicts = null;
        // 查询缓存
        dicts = (List<Dict>)redisTemplate.opsForValue().get("dict:"+parentId+":list");
        // 查询数据库
        if(null==dicts||dicts.size()<=0){
            dicts = getDictListByParentIdFromDb(parentId);
            if(null==dicts||dicts.size()<=0){
                // 数据库中没有值
                redisTemplate.opsForValue().set("dict:"+parentId+":list",new ArrayList<Dict>(),1, TimeUnit.MINUTES);
            }else {
                // 数据库中有值，同步redis缓存
                redisTemplate.opsForValue().set("dict:"+parentId+":list",dicts);
            }
        }
        return dicts;
    }

    @Override
    public List<Dict> findByDictCode(String dictCode) {
        QueryWrapper<Dict> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("dict_code",dictCode);
        Dict dict = baseMapper.selectOne(queryWrapper);
        List<Dict> dictListByParentId = this.getDictListByParentId(dict.getId());

        return dictListByParentId;
    }

    @Override
    public String getNameByParentDictCodeAndValue(String industry,Integer id) {
        QueryWrapper<Dict> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("dict_code",industry);
        Dict dict = baseMapper.selectOne(queryWrapper);

        queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("parent_id",dict.getId());
        queryWrapper.eq("value",id);
        Dict dict2 = baseMapper.selectOne(queryWrapper);
        String name = dict2.getName();

        return name;
    }

    @Override
    public List<Dict> returnMethod() {

        QueryWrapper<Dict> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("dict_code","returnMethod");
        Dict dict = baseMapper.selectOne(queryWrapper);
        System.out.println(dict);
        Long id = dict.getId();
        queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("parent_id",id);
        List<Dict> dictList = baseMapper.selectList(queryWrapper);
        List<String> list = new ArrayList<>();
        dictList.forEach(dict1 -> {
            list.add(dict1.getName());
        });
        return dictList;
    }

    @Override
    public List<Dict> moneyUse() {
        QueryWrapper<Dict> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("dict_code","moneyUse");
        Dict dict = baseMapper.selectOne(queryWrapper);
        System.out.println(dict);
        Long id = dict.getId();
        queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("parent_id",id);
        List<Dict> dictList = baseMapper.selectList(queryWrapper);
        List<String> list = new ArrayList<>();
        dictList.forEach(dict1 -> {
            list.add(dict1.getName());
        });
        return dictList;
    }

    /***
     * 数据库字典列表
     * @param parentId
     * @return
     */
    private List<Dict> getDictListByParentIdFromDb(Long parentId) {
        QueryWrapper<Dict> dictQueryWrapper = new QueryWrapper<>();
        dictQueryWrapper.eq("parent_id",parentId);
        List<Dict> dicts = baseMapper.selectList(dictQueryWrapper);
        for (Dict dict : dicts) {
            Long dictId = dict.getId();
            dictQueryWrapper.clear();
            dictQueryWrapper.eq("parent_id",dictId);
            Integer integer = baseMapper.selectCount(dictQueryWrapper);
            if(integer>0){
                dict.setHasChildren(true);
            }
        }
        return dicts;
    }
}
