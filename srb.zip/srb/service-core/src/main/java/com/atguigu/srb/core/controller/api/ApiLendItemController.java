package com.atguigu.srb.core.controller.api;


import com.atguigu.srb.base.util.JwtUtils;
import com.atguigu.srb.common.result.R;
import com.atguigu.srb.core.pojo.vo.InvestVO;
import com.atguigu.srb.core.service.LendItemService;
import com.atguigu.srb.core.service.LendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;

@RestController
@RequestMapping("/api/core/lendItem")
public class ApiLendItemController {

    @Autowired
    private LendService lendService;

    @Autowired
    private LendItemService lendItemService;

    //投资收益回显
    @GetMapping("getInterestCount/{investAmount}/{lendYearRate}/{period}/{returnMethod}")
    public R getInterestCount(
            @PathVariable("investAmount")BigDecimal investAmount,
            @PathVariable("lendYearRate")BigDecimal lendYearRate,
            @PathVariable("period")Integer period,
            @PathVariable("returnMethod")Integer returnMethod
            ){
        System.out.println("investAmount===="+investAmount);//输入的金额
        System.out.println("lendYearRate===="+lendYearRate);//显示的年利率
        System.out.println("period===="+period);//期数
        System.out.println("returnMethod===="+returnMethod);//还款方式

        BigDecimal interestCount = new BigDecimal("0");

        interestCount = lendService.getInterestCount(investAmount,lendYearRate,period,returnMethod);

        return R.ok().data("interestCount",interestCount);
    }

    //提交投资表单
    @PostMapping("commitInvest")
    public R commitInvest(@RequestBody InvestVO investVO, HttpServletRequest request){

        String token = request.getHeader("token");
        Long userId = JwtUtils.getUserId(token);
        String userName = JwtUtils.getUserName(token);

        investVO.setInvestUserId(userId);
        investVO.setInvestName(userName);
        //构建充值表单
        String form = lendItemService.commitInvest(investVO);

        return R.ok().data("form",form);
    }
}
