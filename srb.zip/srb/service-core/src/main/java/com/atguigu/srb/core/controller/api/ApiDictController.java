package com.atguigu.srb.core.controller.api;


import com.atguigu.srb.common.result.R;
import com.atguigu.srb.core.pojo.entity.Dict;
import com.atguigu.srb.core.service.DictService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/core/dict")
public class ApiDictController {

    @Autowired
    DictService dictService;

    //根据dictcode获取下级节点信息
    @GetMapping("findByDictCode/{dictCode}")
    public R findByDictCode(@PathVariable String dictCode){
        List<Dict> list = dictService.findByDictCode(dictCode);
        return R.ok().data("dictList",list);
    }

    //获取还款方式的下拉列表
    @GetMapping("getDictListByDictCode/returnMethod")
    public R returnMethod(){
        List<Dict> list = dictService.returnMethod();
        return R.ok().data("list",list);
    }

    //获取资金用途的下拉列表
    @GetMapping("getDictListByDictCode/moneyUse")
    public R moneyUse(){
        List<Dict> list = dictService.moneyUse();
        return R.ok().data("list",list);
    }


}
